package PARCIALPOO;

public interface comparable {
}
