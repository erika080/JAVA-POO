package examfinal;

public interface Cargable {

    Double calcularPeso();


}
